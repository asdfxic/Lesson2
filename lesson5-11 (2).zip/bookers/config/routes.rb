Rails.application.routes.draw do
  root to: 'homes#top'
  resources :books #これ1つで7つの個別のルーティングを行わなくてもよい
  
end 
